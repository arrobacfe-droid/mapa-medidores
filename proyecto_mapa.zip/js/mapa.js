
var map=L.map('map').setView([32.5,-115.1],10);

L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png',{
 attribution:'© OpenStreetMap'
}).addTo(map);

fetch('datos.csv')
.then(r=>r.text())
.then(t=>{
 const filas=t.split(/\r?\n/);
 for(let i=1;i<filas.length;i++){
   const c=filas[i].split(',');
   if(c.length<5) continue;

   const estado=(c[4]||'').trim().toUpperCase();
   if(estado==='IOT' || estado==='EOS') continue;

   const lat=parseFloat(c[2]);
   const lng=parseFloat(c[3]);

   if(isNaN(lat)||isNaN(lng)) continue;

   L.marker([lat,lng]).addTo(map)
    .bindPopup('ID: '+c[1]+'<br>Dirección: '+c[0]);
 }
});

function buscar(){
 const lat=parseFloat(document.getElementById('lat').value);
 const lng=parseFloat(document.getElementById('lng').value);
 if(!isNaN(lat)&&!isNaN(lng)){
   map.setView([lat,lng],18);
 }
}
